import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { v1 } from "./v1";
import { auth } from "./auth";
import { library } from "./library";

const app = new Hono<{ Bindings: HttpBindings }>();

const limitRequestBody = bodyLimit({ maxSize: 50 * 1024 * 1024 });
app.use(async (c, next) => {
  // Some Node clients expose an empty, chunked body stream even for DELETE.
  // Re-wrapping that consumed request breaks the Vite adapter on Node 24, and
  // body limits are only meaningful for methods that accept a request body.
  if (!["POST", "PUT", "PATCH"].includes(c.req.method)) return next();
  return limitRequestBody(c, next);
});
app.route("/api/auth", auth);
app.route("/api/library", library);
app.route("/api/v1", v1);
app.use("/api/trpc/*", async c => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", c => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  const hostname = process.env.HOST?.trim() || "127.0.0.1";
  serve({ fetch: app.fetch, port, hostname }, () => {
    console.log(`Server running on http://${hostname}:${port}/`);
  });
}
